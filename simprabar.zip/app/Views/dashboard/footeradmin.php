<footer class="footer">
        <div class="row align-items-center justify-content-xl-between">
          <div class="col-xl-6">
            <div class="copyright text-center text-xl-left text-muted">
              &copy; <?= date('Y') ?> <a href="https://www.creative-tim.com" class="font-weight-bold ml-1" target="_blank">TIM IT RSBY</a>
            </div>
          </div>
          
        </div>
      </footer>